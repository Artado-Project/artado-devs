-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost
-- Üretim Zamanı: 12 Oca 2026, 15:04:23
-- Sunucu sürümü: 8.0.40
-- PHP Sürümü: 8.3.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `artadodevs`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `announcements`
--

CREATE TABLE `announcements` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Tablo döküm verisi `announcements`
--

INSERT INTO `announcements` (`id`, `title`, `description`, `created_at`, `user_id`) VALUES
(2, 'Duyuru @ArusOS geliştiriliyor', 'ArusOS geliştirilmeye başlandı', '2024-12-22 13:34:48', NULL);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `projects`
--

CREATE TABLE `projects` (
  `id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `version` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `features` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `upload_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `project_images`
--

CREATE TABLE `project_images` (
  `id` int NOT NULL,
  `project_id` int DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profile_photo` varchar(255) DEFAULT NULL,
  `two_factor_enabled` tinyint(1) DEFAULT '0',
  `two_factor_secret` varchar(255) DEFAULT NULL,
  `role` enum('user','admin') DEFAULT 'user',
  `website` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `birthday` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `profile_photo`, `two_factor_enabled`, `two_factor_secret`, `role`, `website`, `phone`, `birthday`) VALUES
(1, 'Sxinar', 'oshidev@proton.me', '$2y$10$W2zd0Gl8CYMEgjX3C/gn6uH9AHkNiDwKMgcP50TuVeJ5GdMIPEPoS', 'public/uploads/avatars/avatar_69526142c22e5.png', 0, NULL, 'admin', NULL, '+90 ', NULL),
(2, 'KerimCan05', 'kerim_can05@proton.me', '$2y$10$6XsiOaqOmnKD4CJYvj0W8OC0iJWUETfdpOmdcJWu74z0AN.J0dUSG', 'uploads/profile_photos/profile_67798e81a39e9.png', 0, NULL, 'admin', NULL, NULL, NULL),
(3, 'JodieHolmes', 'ardaakkaya812@gmail.com', '$2y$10$tAVnt9Lm8kFsT2u2RyMXj.dSl.Nl5IQP8B89QLeBJg5aO6XzB4rIa', NULL, 0, NULL, 'user', NULL, NULL, NULL),
(4, 'ardatdev', 'arda@artadosearch.com', '$2y$10$jtNesNkPXrCJR2Fm9XGg4OMjOlCcArhQyzG6dV2NvWuQfLJCz2kqO', NULL, 0, NULL, 'admin', NULL, NULL, NULL),
(11, 'Unkown', 'Unkown.XD@yandex.com', '$2y$10$vwacWqw3QS27tyXivocqpOzhD0BG1RyxvF4.ivul3b.c9M62CxsOq', NULL, 0, NULL, 'user', '', NULL, NULL),
(18, 'yigit', 'yigitkabak@tuta.io', '$2y$10$yQYz3qOaYSCh3iIQZvoK6.adWFlxQ.Cqt9liKaeYBWAjNix7scD76', 'public/uploads/avatars/avatar_681cc2d8699b5.png', 0, NULL, 'user', '', '+90 ', NULL),
(19, 'CaferK', 'cafer.keskin@outlook.com.tr', '$2y$10$RJQgpRdECaHURJzbWAZXruF6PE3t7JvZSlkKjKaCjdndOo1E.82lS', NULL, 0, NULL, 'user', '', NULL, NULL),
(17, 'MrBaxren', 'MrBaxren@proton.me', '$2y$10$xXKkM1o55os1Q7mOmzqsGu0K2lbvvG6mmSzlZzJXXjy9uvxLqf83W', 'uploads/profile_photos/profile_6798c9940b3ed.png', 0, NULL, 'user', '', NULL, NULL),
(10, 'zoda', 'zodaservice@gmail.com', '$2y$10$KEqq8UGxvehh7bDq7baDru3I887CawqtvvOnmBJzhJYU5W96ZefCm', NULL, 0, NULL, 'user', 'https://deso.web.tr', NULL, NULL),
(16, 'qwqweqwe', 'werwer@gmail.com', '$2y$10$qfcQGsyL4Z33j4Z8uxln.O02ulP2NCl1j27B1pUI7ToV91H.d8BsO', NULL, 0, NULL, 'user', '', NULL, NULL),
(15, 'CinarY', 'cinaryilmaz.gnu@gmail.com', '$2y$10$qk2jtw11kyEvEcz4e0gvve4hQs3XsYUCvkDeFS68gfCgCfr6zAePS', NULL, 0, NULL, 'user', 'https://arnolxu.github.io/', NULL, NULL),
(20, 'Nnoe', 'cuus0001@gmail.com', '$2y$10$DwsoTKWRkUPW.XHwu7Jxg.LhaX3PfciIYqP2fnX6DtCaEJrsOtnDi', 'uploads/profile_photos/profile_67d212eb193e5.jpg', 0, NULL, 'user', '', NULL, NULL),
(21, 'fffuya.4', 'umut.bilen1@outlook.com', '$2y$10$FOluM/eNyKhixrG4drvthuSoZnpwHDYnWZguNne3tUmTZ.FOkjxiO', NULL, 0, NULL, 'user', '', NULL, NULL),
(22, 'Hello', 'dvegcznd@formtest.guru', '$2y$10$g5/3keqwEmbPZnRUpiDUv.YQyNH3U4kA82hCvSgbcxBn.aWEbZZcm', NULL, 0, NULL, 'user', 'https://test.org', NULL, NULL),
(23, 'cakiejoy', 'utkan@utkan.net', '$2y$10$mlERfBaw0Tzf6V0h/65jN.OnWS55MPMRrQ2soHW45vydWDGtnplcS', NULL, 0, NULL, 'user', 'https://utkan.me', NULL, NULL),
(24, 'barnes', 'cxs3982@gmail.com', '$2y$10$A4iKBgayUKFpZilHzaoqC.9HcRVXerViQrFgYt.xXMn6g6RMovScy', NULL, 0, NULL, 'user', 'https://www.idx.dev/', NULL, NULL),
(25, 'MxyAICeo', 'MxyAI64@outlook.com', '$2y$10$w6DxDZw9bw4IAWXVa2OBGOryd5oE9Hy6Y.Ki5Wvb.yr8.ZpKZf5oS', NULL, 0, NULL, 'user', '', NULL, NULL),
(26, 'yugel.com.tr', 'yskstudio@duck.com', '$2y$10$l1dk/mGc/KLE1imQL/KQn.KL1b4A1r34sSX.ZmAZZBeFFcv0lRqjO', NULL, 0, NULL, 'user', 'https://yugel.com.tr/', NULL, NULL),
(27, 'Roxman', 'roxman@telegmail.com', '$2y$10$3auYBkfqGF0HpOhpdQW2lO5jR4gtT1VjGCaSoHnKg8e48arY8VI6C', NULL, 0, NULL, 'user', '', NULL, NULL),
(28, 'az', 'f9230pks@anonaddy.me', '$2y$10$H2ttCbcDBdH/BA.ehQRO0euMfx2fkZIE265eflPqaLbdLl5.WdL1.', NULL, 0, NULL, 'user', '', NULL, NULL),
(29, 'mahmucan', 'erenbalik76@protonmail.com', '$2y$10$8/0IG2DizsayV9rnvfR6WuQcvJnz.U85T6zq1gCduRgGHSv9qGXNu', NULL, 0, NULL, 'user', '', NULL, NULL);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `visit_logs`
--

CREATE TABLE `visit_logs` (
  `id` int NOT NULL,
  `page_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_id` int DEFAULT NULL,
  `visitor_ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `visit_logs`
--

INSERT INTO `visit_logs` (`id`, `page_type`, `target_id`, `visitor_ip`, `user_agent`, `created_at`) VALUES
(1, 'dashboard', 1, '198.41.242.246', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0', '2025-12-28 22:46:36'),
(2, 'dashboard', 1, '198.41.242.246', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0', '2025-12-28 22:46:38'),
(3, 'dashboard', 1, '198.41.242.246', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0', '2025-12-28 22:46:38'),
(4, 'dashboard', 1, '198.41.242.246', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0', '2025-12-28 22:46:39'),
(5, 'dashboard', 1, '172.69.109.192', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0', '2025-12-28 22:50:44'),
(6, 'dashboard', 1, '172.69.109.192', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0', '2025-12-28 22:51:10'),
(7, 'dashboard', 1, '172.69.109.192', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0', '2025-12-28 22:51:14'),
(8, 'dashboard', 1, '172.71.95.137', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0', '2025-12-28 22:52:05'),
(9, 'dashboard', 1, '172.69.109.192', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0', '2025-12-28 23:00:10'),
(10, 'dashboard', 1, '162.159.113.69', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0', '2025-12-28 23:04:28'),
(11, 'dashboard', 1, '172.71.98.39', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0', '2025-12-28 23:15:27'),
(12, 'dashboard', 1, '172.71.103.163', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0', '2025-12-29 09:36:29'),
(13, 'dashboard', 1, '172.71.182.231', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0', '2025-12-29 10:09:46'),
(14, 'dashboard', 1, '172.71.103.164', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0', '2025-12-29 10:10:59'),
(15, 'dashboard', 1, '172.69.109.192', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0', '2025-12-29 11:08:21'),
(16, 'dashboard', 1, '172.70.46.219', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0', '2025-12-29 11:26:45'),
(17, 'dashboard', 15, '172.69.109.141', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '2025-12-29 19:41:58');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Tablo için indeksler `project_images`
--
ALTER TABLE `project_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `project_id` (`project_id`);

--
-- Tablo için indeksler `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Tablo için indeksler `visit_logs`
--
ALTER TABLE `visit_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_page_type` (`page_type`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Tablo için AUTO_INCREMENT değeri `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- Tablo için AUTO_INCREMENT değeri `project_images`
--
ALTER TABLE `project_images`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- Tablo için AUTO_INCREMENT değeri `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- Tablo için AUTO_INCREMENT değeri `visit_logs`
--
ALTER TABLE `visit_logs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
